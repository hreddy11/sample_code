from flask import Blueprint, request, jsonify
from airflow.www.app import csrf
from airflow.plugins_manager import AirflowPlugin
from airflow.models import DagBag
from google.cloud import storage
from flask import Blueprint, render_template

from datetime import datetime, timedelta

# Initialize GCS client
storage_client = storage.Client()

# Create Blueprint
custom_ui = Blueprint(
    "custom_ui", __name__,
    template_folder='templates',
    static_folder='static',
    static_url_path='/static/'
)


# GCS bucket name
BUCKET_NAME = 'your-bucket-name'

@custom_ui.route('/custom')
def index():
    current_date = datetime.now()
    current_week = current_date.isocalendar()[1]
    current_week = (current_week + 25 - 1) % 52 + 1  # Ensure it wraps around to next year if needed
    return render_template('custom_ui.html', current_week=current_week)

@custom_ui.route('/get_files')
def get_files():
    bucket = storage_client.bucket(BUCKET_NAME)
    blobs = bucket.list_blobs()
    files = [blob.name for blob in blobs]
    
    if files:
        return jsonify(files)
    else:
        return jsonify({"message": "This week files not created"})

@custom_ui.route('/get_table_info', methods=['POST'])
def get_table_info():
    table_name = request.json['table_name']
    # Implement logic to fetch table info
    # This is a placeholder
    table_info = f"Info for table: {table_name}"
    return jsonify({"table_info": table_info})

@custom_ui.route('/trigger_dag', methods=['POST'])
@csrf.exempt
def trigger_dag():
    dag_id = request.json['dag_id']
    dagbag = DagBag()
    if dag_id not in dagbag.dags:
        return jsonify({"error": "DAG not found"}), 404
    
    # Trigger DAG
    dagbag.get_dag(dag_id).create_dagrun(
        run_id=f'manual__{dag_id}',
        state='running',
        conf={},
        external_trigger=True
    )
    return jsonify({"message": f"DAG {dag_id} triggered successfully"})

# Airflow plugin
class CustomUIPlugin(AirflowPlugin):
    name = "custom_ui_plugin"
    flask_blueprints = [custom_ui]




